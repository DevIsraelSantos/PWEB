var http = require('http');
var server = http.createServer( function(req, res){
    var opcao = req.url;

    if(opcao=='/historia'){
        res.end("<html><body>historia</body></html>");
    } else if(opcao=='/cursos'){
        res.end("<html><body>cursos teste</body></html>");
    } else if(opcao=='/professores'){
        res.end("<html><body>professores</body></html>");
    }else{
        res.end("<html><body>Site da fatec</body></html>");
    }

});
server.listen(3000);